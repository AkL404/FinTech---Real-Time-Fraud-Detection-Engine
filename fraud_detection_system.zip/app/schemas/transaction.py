from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class TransactionBase(BaseModel):
    amount: float
    currency: str = "USD"
    user_id: str
    merchant_id: str
    ip_address: Optional[str] = None
    device_id: Optional[str] = None

class TransactionCreate(TransactionBase):
    pass

class TransactionResponse(TransactionBase):
    id: str
    timestamp: datetime
    risk_score: float
    is_flagged: bool

    class Config:
        from_attributes = True
