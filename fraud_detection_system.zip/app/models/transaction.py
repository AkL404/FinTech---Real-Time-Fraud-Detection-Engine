from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql import func
from app.core.database import Base
import uuid

def generate_uuid():
    return str(uuid.uuid4())

class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    amount = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    user_id = Column(String, index=True)
    merchant_id = Column(String, index=True)
    
    # Risk Analysis
    risk_score = Column(Float, default=0.0)
    is_flagged = Column(Boolean, default=False)
    
    # Metadata
    ip_address = Column(String, nullable=True)
    device_id = Column(String, nullable=True)
