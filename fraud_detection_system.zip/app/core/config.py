from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Fraud Detection System"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = "sqlite:///./test.db" # Default to SQLite for easy local dev
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Isolation Forest Model Path
    MODEL_PATH: str = "model.joblib"

    class Config:
        env_file = ".env"

settings = Settings()
