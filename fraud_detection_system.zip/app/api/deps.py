def get_db():
    return None
