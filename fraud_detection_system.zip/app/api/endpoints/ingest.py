from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from app.api import deps
from app.core.database import get_db
from app.schemas.transaction import TransactionCreate, TransactionResponse
from app.models.transaction import Transaction
from app.services.ml import ml_service
from app.services.rules import rule_engine
from app.worker import send_alert_email

router = APIRouter()

@router.post("/ingest", response_model=TransactionResponse)
def ingest_transaction(
    *,
    db: Session = Depends(get_db),
    transaction_in: TransactionCreate,
    background_tasks: BackgroundTasks # Use FastAPI background tasks for async triggers if needed, or call celery directly
):
    # 1. Feature Engineering & ML Prediction
    # Convert Pydantic model to dict
    features = transaction_in.model_dump()
    ml_risk_score = ml_service.predict(features)
    
    # 2. Rule Engine Check
    is_rule_flagged, rule_reason = rule_engine.check_rules(transaction_in)
    
    # 3. Final Decision Logic
    # Simple logic: if ML score > 0.8 OR Rule Triggered
    final_risk_score = ml_risk_score
    is_flagged = is_rule_flagged or (ml_risk_score > 0.8)
    
    # 4. Persistence
    db_obj = Transaction(
        amount=transaction_in.amount,
        currency=transaction_in.currency,
        user_id=transaction_in.user_id,
        merchant_id=transaction_in.merchant_id,
        ip_address=transaction_in.ip_address,
        device_id=transaction_in.device_id,
        risk_score=final_risk_score,
        is_flagged=is_flagged
    )
    db.add(db_obj)
    db.commit()
    db.refresh(db_obj)
    
    # 5. Alerting (Async)
    if is_flagged:
        reason = rule_reason if rule_reason else "High ML Risk Score"
        # Trigger Celery Task
        send_alert_email.delay(transaction_id=db_obj.id, reason=reason)
        
    return db_obj
