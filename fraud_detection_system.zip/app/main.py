from fastapi import FastAPI
from app.api.endpoints import ingest
from app.core.database import engine, Base
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create DB Tables
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title="Fraud Detection System", lifespan=lifespan)

app.include_router(ingest.router, prefix="/api/v1", tags=["ingest"])

@app.get("/health")
def health_check():
    return {"status": "ok"}
