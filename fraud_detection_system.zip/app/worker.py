from celery import Celery
from app.core.config import settings
import time

celery_app = Celery(
    "worker",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL
)

@celery_app.task
def send_alert_email(transaction_id: str, reason: str):
    # Simulate email sending latency
    time.sleep(1) 
    print(f"ALERT SENT for Transaction {transaction_id}: {reason}")
    return f"Email sent for {transaction_id}"
