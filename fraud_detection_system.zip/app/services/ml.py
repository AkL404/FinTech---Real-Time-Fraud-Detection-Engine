import joblib
import pandas as pd
import numpy as np
from app.core.config import settings
import os

class FraudModel:
    def __init__(self):
        self.model = None
        self._load_model()

    def _load_model(self):
        # In a real scenario, we load the model from a file or bucket
        # For this prototype, if model file doesn't exist, we train a dummy one or mock it.
        # This prevents startup errors if no model is present.
        if os.path.exists(settings.MODEL_PATH):
            self.model = joblib.load(settings.MODEL_PATH)
        else:
            print(f"Model not found at {settings.MODEL_PATH}. Using mock prediction.")
            self.model = None

    def predict(self, features: dict) -> float:
        """
        Returns anomaly score. Lower is more anomalous in Isolation Forest, 
        but we normalize or interpret as risk score (0 to 1).
        """
        if not self.model:
            # Mock logic: high amount = high risk
            amount = features.get("amount", 0)
            if amount > 10000:
                return 0.9
            return 0.1
        
        # Transform dict to df/array
        df = pd.DataFrame([features])
        # Prediction: -1 for outlier, 1 for inlier
        # Score_samples: lower is more anomalous
        try:
            score = self.model.decision_function(df)
            # Normalize or map to 0-1 risk
             # logic depends on training. Assuming mock for now.
            return float(score[0]) 
        except Exception as e:
            print(f"Prediction error: {e}")
            return 0.0

ml_service = FraudModel()
