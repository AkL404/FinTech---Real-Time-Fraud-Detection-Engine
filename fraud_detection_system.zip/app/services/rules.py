from app.schemas.transaction import TransactionCreate

class RuleEngine:
    def check_rules(self, transaction: TransactionCreate) -> tuple[bool, str]:
        """
        Returns (is_flagged, reason)
        """
        # Rule 1: Amount > 50000
        if transaction.amount > 50000:
            return True, "Global Amount Limit Exceeded"
        
        # Rule 2: Suspicious IP (Mock)
        if transaction.ip_address == "1.2.3.4":
            return True, "Blacklisted IP"
            
        return False, None

rule_engine = RuleEngine()
