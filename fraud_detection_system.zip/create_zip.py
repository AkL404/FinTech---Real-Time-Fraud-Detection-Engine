import os
import zipfile

def zip_directory(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            # Exclude specific directories
            dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', 'venv', '.venv', '.idea', '.vscode']]
            
            for file in files:
                # Exclude specific files
                if file in ['.DS_Store', 'test.db'] or file.endswith('.pyc') or file.endswith('.zip'):
                    continue
                
                file_path = os.path.join(root, file)
                # Create relative path for the zip archive
                arcname = os.path.relpath(file_path, folder_path)
                zipf.write(file_path, arcname)
                print(f"Added {arcname}")

if __name__ == "__main__":
    current_dir = os.getcwd()
    zip_name = "fraud_detection_system.zip"
    print(f"Zipping {current_dir} to {zip_name}...")
    zip_directory(current_dir, zip_name)
    print("Done!")
